var colours = {};
colours[C_SI] = "sandybrown";
colours[C_RS] = "sandybrown";

// Form
colours[C_FORM] = "gold";
colours[C_NORMAL_GROUP] = "gold";
colours[C_COMMON_GROUP] = "gold";
colours[C_PLACEHOLDER] = "gold";
colours[C_BC_QUESTION] = "gold";
colours[C_QUESTION] = "gold";
colours[C_TEXTLABEL] = "gold";
colours[C_MAPPING] = "gold";
colours[C_COMMON_ITEM] = "gold";

// BCs  
colours[C_BC] = "crimson";
colours[C_BC_DATATYPE] = "crimson";
colours[C_BC_ITEM] = "crimson";
colours[C_BC_PROP] = "crimson";
colours[C_BC_PROP_VALUE] = "crimson";
colours[C_BCT] = "salmon";

// SDTM
colours[C_USERDOMAIN] = "royalblue";
colours[C_USERVARIABLE] = "royalblue";
colours[C_SDTM_IG] = "dodgerblue";
colours[C_IGDOMAIN] = "dodgerblue";
colours[C_IGVARIABLE] = "dodgerblue";
colours[C_CLASSDOMAIN] = "deepskyblue";
colours[C_CLASSVARIABLE] = "deepskyblue";
colours[C_MODELVARIABLE] = "powderblue";
colours[C_MODEL] = "powderblue";
colours[C_SDTM_CLASSIFICATION] = "orchid";
colours[C_SDTM_TYPE] = "blueviolet";
colours[C_SDTM_COMPLIANCE] = "fuchsia";

// Thesaurus
colours[C_TH] = "green";
colours[C_THC] = "green";

// Refs
colours[C_TC_REF] = "whitesmoke";
colours[C_P_REF] = "whitesmoke";
colours[C_BC_REF] = "whitesmoke";
colours[C_BCT_REF] = "whitesmoke";
colours[C_T_REF] = "whitesmoke";
colours[C_C_REF] = "whitesmoke";
