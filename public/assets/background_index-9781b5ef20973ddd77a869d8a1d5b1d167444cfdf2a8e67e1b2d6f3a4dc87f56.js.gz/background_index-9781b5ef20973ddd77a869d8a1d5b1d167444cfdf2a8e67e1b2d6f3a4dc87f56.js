$(document).ready(function() {

  check();
  
  function check () {
    setTimeout(function(){
      location.reload(true);
    }, 10000);
  }
 
});
